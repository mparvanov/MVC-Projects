﻿using System.Web.Mvc;
using TelerikMvcAppCheckboxValidation.Models;

namespace TelerikMvcAppCheckboxValidation.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "Welcome to ASP.NET MVC!";

            return View(new HomeViewModel { 
                Switch = false,
                Checkbox = true
            });
        }

        [HttpPost]
        public ActionResult Index(HomeViewModel model)
        {           
            return View(model);
        }
    }
}
