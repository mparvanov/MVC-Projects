﻿using System.ComponentModel.DataAnnotations;

namespace TelerikMvcAppCheckboxValidation.Models
{
    public class HomeViewModel
    {
        [Required]
        public bool Switch { get; set; }

        [Required]
        public bool Checkbox { get; set; }
    }
}