﻿using System.ComponentModel.DataAnnotations;
namespace TelerikAspNetCoreApp2.Models
{
    public class SampleViewModel
    {
        [UIHint("DecimalForAmount")]
        public decimal AmountValue
        {
            get;
            set;
        }

    }
}
