﻿$(function () {

    $(document).on('keydown', 'input.k-input.amount[data-role="numerictextbox"]', function (e) {
        if (e.keyCode === KeyEvent.DOM_VK_K
            || e.keyCode === KeyEvent.DOM_VK_M
            || e.keyCode === KeyEvent.DOM_VK_B
            || e.keyCode === KeyEvent.DOM_VK_T
        ) {
            var numerictextbox = $(this).data("kendoNumericTextBox");
            var newValue = e.target.value;
            switch (e.keyCode) {
                case KeyEvent.DOM_VK_K:
                    numerictextbox.value(newValue * 1000);
                    debugger;
                    numerictextbox.trigger("change");
                    break;
                case KeyEvent.DOM_VK_M:
                    numerictextbox.value(newValue * 1000000);
                    break;
                case KeyEvent.DOM_VK_B:
                    numerictextbox.value(newValue * 1000000000);
                    break;
                case KeyEvent.DOM_VK_T:
                    numerictextbox.value(newValue * 1000000000000);
                    break;
                default:
                    console.log('KeyCode is out of range.');
            }
        }

    });

});
